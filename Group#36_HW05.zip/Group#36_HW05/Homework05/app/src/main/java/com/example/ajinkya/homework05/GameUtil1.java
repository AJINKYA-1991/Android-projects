package com.example.ajinkya.homework05;

import android.util.Log;
import android.util.Xml;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

/**
 * Created by Ajinkya on 2/17/2017.
 */

public class GameUtil1 extends DefaultHandler {
    Game game,game1;
    StringBuilder xmlInnerText;
    ArrayList<Game> similar_games;
    ArrayList<String> genres;
    String img_url="";
    int img_flag=0;

    public Game getGame() {
        return game;
    }

    static Game parser(InputStream in) throws IOException, SAXException {
        GameUtil1 parser=new GameUtil1();
        Xml.parse(in, Xml.Encoding.UTF_8,parser);
        return parser.getGame();
    }

    @Override
    public void startDocument() throws SAXException {
        super.startDocument();
        game=new Game();
        xmlInnerText=new StringBuilder();
    }

    @Override
    public void endDocument() throws SAXException {
        super.endDocument();
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        super.startElement(uri, localName, qName, attributes);
        if(localName.equals("SimilarCount")){
            game1=new Game();
            similar_games=new ArrayList<Game>();
        }else if (localName.equals("Genres")){
            genres=new ArrayList<String>();
        }

    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        super.endElement(uri, localName, qName);
        if(game!=null){
            if(localName.equals("baseImgUrl")){
                img_url=xmlInnerText.toString().trim();
            }else if(localName.equals("GameTitle")){
                game.setGametitle(xmlInnerText.toString().trim());
            }else if(localName.equals("Overview")){
                game.setOverview(xmlInnerText.toString().trim());
            }else if(localName.equals("Publisher")){
                game.setPublisher(xmlInnerText.toString().trim());
            }else if(localName.equals("Youtube")){
                game.setYoutube(xmlInnerText.toString().trim());
            }else if(localName.equals("SimilarCount")){
                game.setSimilarCount(Integer.parseInt(xmlInnerText.toString().trim()));
            }else if(localName.equals("boxart")||localName.equals("original")||localName.equals("thumb")){
                if(img_flag==0){
                    img_url+=xmlInnerText.toString().trim();
                    game.setImageUrl(img_url);
                    img_flag=1;
                }
            }
        }
        if(game1!=null&&similar_games!=null){
            if(localName.equals("id")){
                game1.setid123(Integer.parseInt(xmlInnerText.toString().trim()));
                Log.d("demowerock",xmlInnerText.toString().trim());
            }else if (localName.equals("PlatformId")){
                game1.setPlatform1(Integer.parseInt(xmlInnerText.toString().trim()));
                Log.d("demowe",xmlInnerText.toString().trim());
            }
            else if (localName.equals("Game")){
                similar_games.add(game1);
                Log.d("demo","adding from list");
            }else if(localName.equals("Similar")){
                game.setSimilarGames(similar_games);
                Log.d("demo","similarity found");
            }
        }else{
            Log.d("demo","not getting anything");
        }
        if(genres!=null){
            if(localName.equals("genre")){
                genres.add(xmlInnerText.toString().trim());
            }else if(localName.equals("Genres")){
                game.setGenre(genres);
            }
        }
        xmlInnerText.setLength(0);

    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        super.characters(ch, start, length);
        xmlInnerText.append(ch,start,length);
    }
}
