package com.example.ajinkya.homework05;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;
import android.widget.VideoView;

public class WebViewActivity extends AppCompatActivity {
    VideoView videoView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TextView textView2;
        setContentView(R.layout.activity_web_view);
        getSupportActionBar().setTitle("WebView");
        String url=getIntent().getStringExtra("YOURL");
        WebView webview = (WebView) findViewById(R.id.webView);
        //view.setEnabled(true);
        webview.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                WebViewActivity.this.setTitle(view.getTitle());
                view.setEnabled(true);
            }
        });
        textView2 = (TextView) findViewById(R.id.textView11);
        String title=getIntent().getStringExtra("TITLE");
        String str ="@ Trailer";
        String newstr = title + str;
        textView2.setText(newstr);
        webview.setWebViewClient(new WebViewClient());
        webview.getSettings().setJavaScriptEnabled(true);
        webview.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            webview.getSettings().setMediaPlaybackRequiresUserGesture(false);
        }
        webview.setWebChromeClient(new WebChromeClient());
        webview.loadUrl(url);



    }
}
