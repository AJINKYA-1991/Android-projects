package com.example.ajinkya.homework05;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.squareup.picasso.Picasso;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class Game_Details extends AppCompatActivity implements getAsyncTask1.IActivity{
    TextView tv;
    String titile;
    static Game game;
    TextView tv1,tv2,tv3,tv4,tv5;
    EditText editText2;
    ArrayList<Integer> arrayList = new ArrayList<Integer>();
    ArrayList<Game> gameList = new ArrayList<Game>();
    int size;
    ImageView iv;
    ProgressBar pb;
    int j =0;
    Game gamenew;
    TextView tv8;
    Button button,button1,button2;
    String youtub_link;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game__details);
        getSupportActionBar().setTitle("Game Details");
        pb= (ProgressBar) findViewById(R.id.progressBar1);
        Bundle bundle = getIntent().getExtras();
        String title = bundle.getString(MainActivity.TITLE_KEY);
        String id = bundle.getString(MainActivity.ID_KEY);
        Log.d("Date12",title);
        Log.d("Date13",id);
        tv = ((TextView)findViewById(R.id.textView2));
        iv = ((ImageView) findViewById(R.id.imageView));
        tv1 = ((TextView)findViewById(R.id.textView2));
        tv2 = ((TextView)findViewById(R.id.textView3));
        tv3 = ((TextView)findViewById(R.id.textView5));
        tv8 = ((TextView)findViewById(R.id.textView22));
    /*    tv4 = ((TextView)findViewById(R.id.textView));
        tv5 = ((TextView)findViewById(R.id.textView));*/
        button = ((Button) findViewById(R.id.button));
        button1 = ((Button) findViewById(R.id.button4));
        button2 = ((Button) findViewById(R.id.button5));
        editText2 = ((EditText) findViewById(R.id.editText2));
        tv.setText(title);
        tv.setVisibility(View.GONE);
        editText2.setVisibility(View.GONE);
        tv1.setVisibility(View.GONE);
        tv8.setVisibility(View.GONE);
        tv2.setVisibility(View.GONE);
        tv3.setVisibility(View.GONE);
        new getAsyncTask1(Game_Details.this).execute("http://thegamesdb.net/api/GetGame.php?id="+id);
        //http://thegamesdb.net/api/GetGame.php?id=7256
    }
    public void setList(final Game game) {
        this.game = game;
       /* size = gameList.size();
        gamenew = gameList.get(j);*/
        if(game!=null) {
            button.setVisibility(View.VISIBLE);
            pb.setVisibility(View.INVISIBLE);
            editText2.setVisibility(View.VISIBLE);
            tv.setVisibility(View.VISIBLE);
            tv1.setVisibility(View.VISIBLE);
            tv2.setVisibility(View.VISIBLE);
            tv3.setVisibility(View.VISIBLE);
            tv8.setVisibility(View.VISIBLE);
            button1.setVisibility(View.VISIBLE);
            button2.setVisibility(View.VISIBLE);
            arrayList = game.getid123();
            Log.d("arraylist", String.valueOf(arrayList));
            Log.d("Iamgeurl",game.getImageUrl());
            titile = game.getGametitle();
            Picasso.with(this).load(game.getImageUrl()).into(iv);
            if (game.getPublisher() == null) {
                ((TextView) findViewById(R.id.textView6)).setText("");
            } else {
                ((TextView) findViewById(R.id.textView6)).setText(game.getPublisher());
            }
            ((EditText) findViewById(R.id.editText2)).setText(game.getOverview());
            ((EditText) findViewById(R.id.editText2)).setTextColor(Color.BLACK);
            //((TextView) findViewById(R.id.textView4)).setText(game.getGenre());
            String g="";
            int flag=0;
            if(game.getGenre()!=null){
                for(String genre:game.getGenre()){
                    if(flag==0){
                        g+=genre;
                        flag=1;
                    }else{
                        g+=", "+genre;
                    }
                }
                ((TextView) findViewById(R.id.textView4)).setText(g);
            }

            youtub_link = game.getYoutube();
        }


    }

    public void Play_Trailer(View view)
    {
        /*WebView wv=(WebView)findViewById(R.id.webView);
        wv.getSettings().setJavaScriptEnabled(true);
        wv.loadUrl("http://www.youtube.com/watch?v=F-QbeGO6d9o");*/
        //Log.d("youtubelink",youtub_link);
        if(youtub_link!=null){
            Intent i=new Intent(Game_Details.this,WebViewActivity.class);
            i.putExtra("YOURL",youtub_link);
            i.putExtra("TITLE",titile);
            startActivity(i);
        }else{
            Toast.makeText(Game_Details.this,"No trailer FOUND FOR  this game",Toast.LENGTH_SHORT).show();
        }
    }

    public void finish(View view) {
        finish();
    }

    public void similar_games(View view) {
        if(arrayList.size()>0){
            Intent i=new Intent(Game_Details.this,Similar_Games.class);
            i.putExtra("SIMilar GAMES",arrayList);
            i.putExtra("TITLE",Game_Details.game.getGametitle());
            startActivity(i);
        }else{
            Toast.makeText(Game_Details.this,"No similar games found",Toast.LENGTH_SHORT).show();
        }
    }
}
