package com.example.ajinkya.homework05;

import android.util.Log;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

/**
 * Created by Ajinkya on 2/15/2017.
 */

public class GameUtil {
    static public class NewspullParser {

        static ArrayList<Game> parseGame(InputStream in) throws Exception {
            String check = "";
            XmlPullParser parser = XmlPullParserFactory.newInstance().newPullParser();
            parser.setInput(in, "UTF-8");
            Game games = null;
            ArrayList<Game> GameArrayList = new ArrayList<>();
            int event = parser.getEventType();
            String windSpeed = "";


            while (event != XmlPullParser.END_DOCUMENT) {
                switch (event) {
                    case XmlPullParser.START_TAG:
                        Log.d("demo",parser.getName());
                        if(parser.getName().equals("Game")){
                            games = new Game();
                            //check = parser.nextText();
                        }
                        else if(parser.getName().equals("id"))
                        {
                            games.setId(parser.nextText().trim());
                        }
                        else if(parser.getName().equals("GameTitle"))
                        {
                            games.setGametitle(parser.nextText().trim());
                        }
                        else if(parser.getName().equals("ReleaseDate"))
                        {
                            games.setReleasedt(parser.nextText().trim());
                        }
                        else if(parser.getName().equals("Platform"))
                        {
                            games.setPlatform(parser.nextText().trim());
                        }
                        //break;
                        break;
                    case XmlPullParser.END_TAG:
                        if (parser.getName().equals("Game")) {
                            Log.d("demo","end");
                            GameArrayList.add(games);
                            games = null;
                        }

                        break;
                }
                event = parser.next();
            }

            return GameArrayList;
        }
        /*static private void skip(XmlPullParser parser) throws XmlPullParserException, IOException {
            if (parser.getEventType() != XmlPullParser.START_TAG) {
                throw new IllegalStateException();
            }
            int depth = 1;
            while (depth != 0) {
                switch (parser.next()) {
                    case XmlPullParser.END_TAG:
                        depth--;
                        break;
                    case XmlPullParser.START_TAG:
                        depth++;
                        break;
                }
            }
        }*/
    }

}
