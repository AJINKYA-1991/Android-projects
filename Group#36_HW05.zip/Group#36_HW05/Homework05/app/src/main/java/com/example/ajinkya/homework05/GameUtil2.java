package com.example.ajinkya.homework05;

import android.util.Log;
import android.util.Xml;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

/**
 * Created by Ajinkya on 2/18/2017.
 */

public class GameUtil2 extends DefaultHandler {
    Game game;
    int flag=0;
    StringBuilder xmlInnerText;

    public Game getGame() {
        return game;
    }

    static Game parser(InputStream in) throws IOException, SAXException {
        GameUtil2 p=new GameUtil2();
        Xml.parse(in, Xml.Encoding.UTF_8,p);
        return p.getGame();
    }

    @Override
    public void startDocument() throws SAXException {
        super.startDocument();
        xmlInnerText=new StringBuilder();
        game=new Game();
    }

    @Override
    public void endDocument() throws SAXException {
        super.endDocument();
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        super.endElement(uri, localName, qName);
        SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");
        if(localName.equals("GameTitle")){
            game.setGametitle(xmlInnerText.toString().trim());
        }else if(localName.equals("id")){
            if(flag==0){
                Log.d("demo5",xmlInnerText.toString().trim());
                game.setId1(Integer.parseInt(xmlInnerText.toString().trim()));
                flag=1;
            }
        }else if(localName.equals("Platform")){
            game.setPlatform((xmlInnerText.toString().trim()));
        }else if(localName.equals("ReleaseDate")){
            try {
                Log.d("demo","RelDate..."+xmlInnerText.toString());
                game.setReleaseDate(format.parse(xmlInnerText.toString().trim()));
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
        xmlInnerText.setLength(0);
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        super.startElement(uri, localName, qName, attributes);
    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        super.characters(ch, start, length);
        xmlInnerText.append(ch,start,length);
    }
}
