package com.example.ajinkya.homework05;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.annotation.IdRes;
import android.support.annotation.Nullable;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements getAsyncTask.IActivity {
    EditText editText;
    Button button3;
    LinearLayout ll;
    RadioGroup rg;
    String Title,id;
    RadioButton[] rb;
    ProgressBar progressBar;
    ArrayList<Game> gameList = new ArrayList<Game>();
    Game game1;
    int count = 0;
    ScrollView Scroll1;
    static final String TITLE_KEY="value";
    static final String ID_KEY="value1";
    Game gg = new Game();
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().setTitle("The Games DB");
        editText =(EditText)findViewById(R.id.editText);
        button3 = (Button)findViewById(R.id.button3);
        Scroll1 = (ScrollView)findViewById(R.id.Scroll1);
        progressBar= (ProgressBar) findViewById(R.id.progressBar);
        progressBar.setVisibility(View.INVISIBLE);
        findViewById(R.id.button2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isConnectionOnline()){
                    progressBar.setVisibility(View.VISIBLE);
                editText =(EditText)findViewById(R.id.editText);
                String pp = editText.getText().toString();
                Log.d("Search",pp);
                    if(pp.length()==0)
                    {
                        progressBar.setVisibility(View.INVISIBLE);
                        Toast.makeText(getApplicationContext(), "please enter valid games", Toast.LENGTH_SHORT).show();
                    }
                else
                    {
                        new getAsyncTask(MainActivity.this).execute("http://thegamesdb.net/api/GetGamesList.php?name="+pp);}
            }
                else{
                    Toast.makeText(getApplicationContext(), "No Internet Connection", Toast.LENGTH_SHORT).show();
                }
            }
        });

        //new getAsyncTask(MainActivity.this).execute("http://thegamesdb.net/api/GetGamesList.php?name="+editText);
    }
    private  boolean isConnectionOnline(){

        ConnectivityManager cm= (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo=cm.getActiveNetworkInfo();
        if(networkInfo!=null && networkInfo.isConnected())
            return true;
        return false;
    }
    public void setList(ArrayList<Game> games) {
        gameList = games;
        if(gameList.size()==0) {
            progressBar.setVisibility(View.INVISIBLE);
            Toast.makeText(getApplicationContext(), "Please enter a valid game to search", Toast.LENGTH_SHORT).show();
        }//pd.dismiss();

        //Log.d("demo", "In setList");
        /*for (int i = 0; i < gameList.size(); i++) {
            count++;
            //Log.d("demo", "In loop at " + i);
            game1 = gameList.get(i);
            //Log.d("Democ", game1.getPlatform());
            *//*TextView tv = new TextView(this);
            tv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(MainActivity.this, NewsDetailsActivity.class);
                    intent.putExtra(NEWS_KEYS, currentNews);
                    startActivity(intent);
                }
            });*//*
           *//* tv.setText(currentNews.getTitle());
            LinearLayout horizLL = new LinearLayout(this);
            LinearLayout.LayoutParams layout = new LinearLayout.LayoutParams(android.app.ActionBar.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            horizLL.setLayoutParams(layout);
            horizLL.setOrientation(LinearLayout.HORIZONTAL);
            iv.setLayoutParams(layout);
            horizLL.addView(iv);
            horizLL.addView(tv);
            ll.addView(horizLL);*//*

        }
*/

        //Log.d("Demo122", String.valueOf(count));
        rb = new RadioButton[gameList.size()];
        ll = (LinearLayout) findViewById(R.id.ll_scroll);

     /*   ll.setLayoutParams(new ActionBar.LayoutParams(ActionBar.LayoutParams.MATCH_PARENT, 200.0d));
        ll.setOrientation(LinearLayout.VERTICAL);*/

        rg = new RadioGroup(this);
        progressBar.setVisibility(View.INVISIBLE);
        for(int i = 0; i < gameList.size(); i++)
        {
            /*LinearLayout horizLL = new LinearLayout(this);
            LinearLayout.LayoutParams layout = new LinearLayout.LayoutParams(android.app.ActionBar.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            horizLL.setLayoutParams(layout);
            horizLL.setOrientation(LinearLayout.HORIZONTAL);
            ll.addView(horizLL);*/

            //rg.setOrientation(RadioGroup.VERTICAL);
            //rb[i] = new RadioButton(this);
            //rb[i].setId(i);
            RadioButton radioButtonOption=new RadioButton(this);
            //radioButtonOption.setText(questions.getChoices().get(i).toString());
            //radioGroupOptions.addView(radioButtonOption);

            String date = gameList.get(i).getReleasedt();
            String year;
            if(date.length() == 0)
            {
                year = "";
            }
            else {
                year = date.substring(6,date.length());
            }
            String dat1 = "Released in " + year;
            String platform = "Platform:" +gameList.get(i).getPlatform();
            String title = gameList.get(i).getGametitle();
            String result = (title + "."+ dat1 + "." + platform);

            radioButtonOption.setText(result.toString());
            rg.addView(radioButtonOption);
           /* RadioGroup radiogroup = (RadioGroup)findViewById(R.id.RadioGroup01);
            RadioButton rdbtn = new RadioButton(this);
            rdbtn.setId(i);
            rdbtn.setText(text[i]);
            radiogroup.addView(rdbtn);*/
            //ll.addView(rb[i]);
            //||dat1||platform);
        }
       /* LinearLayout ll = new LinearLayout(this);
        ll.setLayoutParams(new ActionBar.LayoutParams(ActionBar.LayoutParams.WRAP_CONTENT, ActionBar.LayoutParams.WRAP_CONTENT));
        ll.setOrientation(LinearLayout.HORIZONTAL);
        Scroll1.addView(ll);*/
        ll.addView(rg);
        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                int selectedId=rg.getCheckedRadioButtonId();
                RadioButton radioButton= (RadioButton) findViewById(selectedId);
                String text = radioButton.getText().toString();
                if(text.length()==0){
                    Toast.makeText(getApplicationContext(), "Please choose a proper item from list", Toast.LENGTH_SHORT).show();
                }
                Title = gameList.get(checkedId-1).getGametitle();
                id = gameList.get(checkedId-1).getId();
                //int find = text.indexOf('.');
                Log.d("Date",Title);
                Log.d("Date1", String.valueOf(checkedId));
                Log.d("Date12", String.valueOf(selectedId));
                button3.setEnabled(true);
                //Log.d("Date1",id);
            }
        });
        //Scroll1.addView(rg);



    }

    public void Goto_NextActivity(View view)
    {
        gg.setsize(0);
        Intent intent=new Intent(MainActivity.this,Game_Details.class);
        intent.putExtra(TITLE_KEY,Title);
        intent.putExtra(ID_KEY,id);
        startActivity(intent);

    }
}

    /*(View view)
    {
        editText =(EditText)findViewById(R.id.editText);
        String pp = editText.toString();
        Log.d("Search",pp.toString());
        new getAsyncTask(MainActivity.this).execute("http://thegamesdb.net/api/GetGamesList.php?name="+pp);

    }*/

