package com.example.ajinkya.homework05;

import android.os.AsyncTask;
import android.util.Log;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

/**
 * Created by Ajinkya on 2/18/2017.
 */

public class getAsyncTask3 extends AsyncTask<String, Game, ArrayList<Game>> {

    getAsyncTask3.IActivity activity;
    ArrayList<Game> games=new ArrayList<Game>();
    public getAsyncTask3(getAsyncTask3.IActivity activity) {
        this.activity = activity;
    }

    @Override
    protected void onPostExecute(ArrayList<Game> game) {
        super.onPostExecute(game);
        if(game!=null){
            activity.setList(game);
            Log.d("3rdapi",game.toString());
        }

    }

    @Override
    protected void onPreExecute() {

    }

    @Override
    protected ArrayList<Game> doInBackground(String... params) {
        try {
            for (int i = 0; i < params.length; i++) {
                URL url = new URL(params[i]);
                HttpURLConnection con = (HttpURLConnection) url.openConnection();
                con.setRequestMethod("GET");
                con.connect();
                int statusCode = con.getResponseCode();
                if (statusCode == HttpURLConnection.HTTP_OK) {
                    InputStream in = con.getInputStream();
                    Log.d("demo", in.toString());
                    publishProgress(GameUtil2.parser(con.getInputStream()));
                }

            }
            return games;
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }

   /* private void publishProgress(ArrayList<Game> games) {
    }*/

    @Override
    protected void onProgressUpdate(Game... values) {
        super.onProgressUpdate(values);
        games.add(values[0]);
        Log.d("demo","to be done");
    }

    public interface IActivity
    {

        public void setList(ArrayList<Game> game);
    }

}
