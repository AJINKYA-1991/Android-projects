package com.example.ajinkya.homework05;

import android.util.Log;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;

/**
 * Created by Ajinkya on 2/15/2017.
 */

public class Game implements Serializable
{
    String id,gametitle,releasedt,platform,overview,genre1,publisher,ImageUrl,youtube;
    Date releaseDate;
    ArrayList<String> genre;
    int id1,similarCount,platform1;
    ArrayList<Game> similarGames;
    //Arraylist arrayList;
    static ArrayList<Integer> arrayList = new ArrayList<Integer>();
    public ArrayList<Game> getSimilarGames() {
        return similarGames;
    }
    public ArrayList<String> getGenre() {
        return genre;
    }
    public int getPlatform1() {
        return platform1;
    }
    public void setGenre(ArrayList<String> genre) {
        this.genre = genre;
    }
    public void setsize(int size) {
        arrayList.clear();
    }
    /*//public ArrayList<String> getGenre() {
        return genre;
    }*/
    public void setPlatform1(int platform) {
        this.platform1 = platform1;
    }
    public void setid123(int p) {
        arrayList.add(p);
        Log.d("List", String.valueOf(arrayList));
    }
    public ArrayList<Integer> getid123() {
        Log.d("List1", String.valueOf(arrayList));
        return arrayList;
    }
    public void setSimilarGames(ArrayList<Game> similarGames) {
        this.similarGames = similarGames;
    }
    public String getYoutube() {
        return youtube;
    }
    public void setYoutube(String youtube) {
        this.youtube = youtube;
    }
    public String getImageUrl() {
        return ImageUrl;
    }
    public void setImageUrl(String ImageUrl) {
        this.ImageUrl = ImageUrl;
    }
    public String getOverview() {
        return overview;
    }
    public void setOverview(String overview) {
        this.overview = overview;
    }
    public String getGenre1() {
        return genre1;
    }
    public void setGenre(String genre1) {
        this.genre1 = genre1;
    }
    public String getPublisher() {
        return publisher;
    }
    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }
    public String getId() {
        return id;
    }
    public Date getReleaseDate() {
        return releaseDate;
    }
    public int getSimilarCount() {
        return similarCount;
    }

    public void setSimilarCount(int similarCount) {
        this.similarCount = similarCount;
    }

    public void setReleaseDate(Date releaseDate) {
        this.releaseDate = releaseDate;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getGametitle() {
        return gametitle;
    }

    public void setGametitle(String gametitle) {
        this.gametitle = gametitle;
    }

    public String getReleasedt() {
        return releasedt;
    }

    public void setReleasedt(String releasedt) {
        this.releasedt = releasedt;
    }
    public int getId1() {
        return id1;
    }
    public void setId1(int id1) {
        this.id1 = id1;
    }
    public String getPlatform() {
        return platform;
    }

    public void setPlatform(String platform) {
        this.platform = platform;
    }

    @Override
    public String toString() {
        return "Game{" +
                "id='" + id + '\'' +
                ", gametitle='" + gametitle + '\'' +
                ", releasedt='" + releasedt + '\'' +
                ", platform='" + platform + '\'' +
                ", overview='" + overview + '\'' +
                ", genre='" + genre + '\'' +
                ", publisher='" + publisher + '\'' +
                ", ImageUrl='" + ImageUrl + '\'' +
                ", Youtube='" + youtube + '\'' +
                ",Date='" + releaseDate + '\'' +
                '}';
    }
}
