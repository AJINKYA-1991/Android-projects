package com.example.ajinkya.homework05;

import android.os.AsyncTask;
import android.util.Log;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

/**
 * Created by Ajinkya on 2/17/2017.
 */

public class getAsyncTask1 extends AsyncTask<String, Void, Game> {

    getAsyncTask1.IActivity activity;
    public getAsyncTask1(getAsyncTask1.IActivity activity) {
        this.activity = activity;
    }

    @Override
    protected void onPostExecute(Game game) {
        if(game!=null){
            super.onPostExecute(game);
            activity.setList(game);
            Log.d("2ndapi",game.toString());
        }

    }

    @Override
    protected void onPreExecute() {

    }

    @Override
    protected Game doInBackground(String... params) {
        try {
            URL url = new URL(params[0]);
            HttpURLConnection con = (HttpURLConnection)url.openConnection();
            con.setRequestMethod("GET");
            con.connect();
            int statusCode = con.getResponseCode();
            if(statusCode == HttpURLConnection.HTTP_OK) {
                InputStream in = con.getInputStream();
                Log.d("demo",in.toString());
                return GameUtil1.parser(con.getInputStream());
            }

        }
        catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }

    public interface IActivity
    {
        public void setList(Game game);
    }

}
