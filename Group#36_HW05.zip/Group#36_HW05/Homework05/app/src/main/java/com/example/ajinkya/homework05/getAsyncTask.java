package com.example.ajinkya.homework05;

import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

/**
 * Created by Ajinkya on 2/15/2017.
 */

public class getAsyncTask extends AsyncTask<String, Void, ArrayList<Game>> {
    IActivity activity;
    public getAsyncTask(IActivity activity) {
        this.activity = activity;
    }

    @Override
    protected void onPostExecute(ArrayList<Game> game) {
        if(game!=null){
            activity.setList(game);
            Log.d("demo",game.toString());
        }
        /*else
        {
            Toast.makeText(getApplicationContext(), "This is a plain toast.", Toast.LENGTH_SHORT).show();
        }*/
    }

    @Override
    protected void onPreExecute() {

    }

    @Override
    protected ArrayList<Game> doInBackground(String... params) {
        try {
            URL url = new URL(params[0]);
            HttpURLConnection con = (HttpURLConnection)url.openConnection();
            con.setRequestMethod("GET");
            con.connect();
            int statusCode = con.getResponseCode();
            if(statusCode == HttpURLConnection.HTTP_OK) {
                InputStream in = con.getInputStream();
                Log.d("demo",in.toString());
                return GameUtil.NewspullParser.parseGame(in);
            }

        }
        catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }

    public interface IActivity
    {
        public void setList(ArrayList<Game> game);
    }


}

