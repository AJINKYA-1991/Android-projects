package com.example.ajinkya.homework05;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
/**
 * Created by Ajinkya on 2/17/2017.
 */
public class Similar_Games extends AppCompatActivity implements getAsyncTask3.IActivity{
    ArrayList<Game> gameArrayList=new ArrayList<Game>();
    ProgressBar pb;
    TextView tv_similar;
    Game gg = new Game();
    LinearLayout ll;
    ScrollView scview;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_similar__games);
        pb= (ProgressBar) findViewById(R.id.progressBar);
        getSupportActionBar().setTitle("Similar Games");
        tv_similar= (TextView) findViewById(R.id.textView7);
        scview= (ScrollView) findViewById(R.id.scrollview);
        String s=getIntent().getStringExtra("TITLE");
        ArrayList games= (ArrayList) getIntent().getSerializableExtra("SIMilar GAMES");
        tv_similar.setVisibility(View.GONE);
        tv_similar.setText("Similar games to "+s);
        Log.d("demo","entering similar");
        if(games!=null){
            Log.d("demo",games.size()+"");
            String[] urls=new String[games.size()];
            for (int i=0;i<games.size();i++){
                urls[i]="http://thegamesdb.net/api/GetGame.php?id="+games.get(i);
                Log.d("urllinks", String.valueOf(games.get(i)));
            }
            findViewById(R.id.button).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    finish();
                }
            });
            new getAsyncTask3(Similar_Games.this).execute(urls);

        }else{
            Log.d("demo","null");
        }
    }
    public void setList(ArrayList<Game> games) {
        LinearLayout ll= (LinearLayout) findViewById(R.id.ll_scroll);
       /* LinearLayout horizLL = new LinearLayout(this);
        LinearLayout.LayoutParams layout = new LinearLayout.LayoutParams(android.app.ActionBar.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        horizLL.setLayoutParams(layout);
        horizLL.setOrientation(LinearLayout.VERTICAL);*/
        //ll.addView(horizLL)
        //LinearLayout ll= new LinearLayout();
        if(games!=null){
            if(games.size()>0){
                for(Game game:games){
                    TextView tv=new TextView(this);
                    if(game!=null){
                        tv.setId(game.getId1());
                        tv_similar.setVisibility(View.VISIBLE);
                        tv.setPadding(0,10,0,10);
                        tv.setTextColor(Color.BLACK);
                        if(game.getReleaseDate()!=null){
                            int length=game.getReleaseDate().toString().length()-4;
                            tv.setText(game.getGametitle()+". Released in "+game.getReleaseDate().toString().substring(length)+". Platform: "+game.getPlatform());
                            ll.addView(tv);
                        }else{
                            tv.setText(game.getGametitle()+". Platform: "+game.getPlatform());
                            ll.addView(tv);
                        }
                        //horizLL.addView(tv);

                       // scview.addView(ll);
                    }
                    //scview.addView(ll);

                }
            }
           // scview.addView(horizLL);
        }
        pb.setVisibility(View.INVISIBLE);
        //gg.setsize(0);
        //pb.setVisibility(View.INVISIBLE);
    }
}
